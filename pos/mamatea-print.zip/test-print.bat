@echo off
cd /d "%~dp0"
mamatea-print.exe -test
